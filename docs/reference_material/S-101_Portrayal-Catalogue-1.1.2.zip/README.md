# S-101 Portrayal-Catalogue
IHO S-101 Portrayal Catalogue development, discussion, and review

[i4]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/4
[i5]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/5
[i6]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/6
[i7]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/7
[i9]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/9
[i10]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/10
[i14]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/14
[i16]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/16
[i18]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/18
[i20]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/20
[i23]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/23
[i24]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/24
[i25]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/25
[i26]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/26
[i27]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/27
[i28]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/28
[i29]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/29
[i30]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/30
[i33]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/33
[i34]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/34
[i36]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/36
[i37]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/37
[i39]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/39
[i40]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/40
[i41]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/41
[i44]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/44
[i46]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/46
[i47]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/47
[i48]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/48
[i49]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/49
[i50]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/50
[i51]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/51
[i52]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/52
[i53]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/53
[i54]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/54
[i55]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/55
[i56]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/56
[i57]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/57
[i59]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/59
[i60]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/60
[i61]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/61
[i62]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/62
[i63]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/63
[i64]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/64
[i65]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/65
[i67]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/67
[i68]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/68
[i69]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/69
[i70]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/70
[i72]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/72
[i73]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/73
[i76]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/76
[i77]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/77
[i78]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/78
[i79]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/79
[i80]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/80
[i82]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/82
[i84]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/84
[i86]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/86
[i89]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/89
[i90]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/90
[i91]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/91
[i92]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/92
[i94]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/94
[i95]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/95
[i96]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/96
[i97]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/97
[i98]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/98
[i100]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/100
[i101]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/101
[i103]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/103
[i104]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/104
[i105]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/105
[i106]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/106
[i107]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/107
[i108]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/108
[i109]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/109
[i110]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/110
[i111]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/111
[i112]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/112
[i113]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/113
[i114]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/114
[i117]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/117
[i119]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/119
[i121]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/121
[i122]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/122
[i125]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/125
[i124]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/124
[i126]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/126
[i131]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/131
[i133]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/133
[i134]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/134
[i137]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/137
[i138]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/138
[i139]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/139
[i140]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/140
[i141]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/141
[i142]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/142
[i143]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/143
[i145]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/145
[i153]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/153
[i154]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/154
[i155]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/155
[i159]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/159
[i160]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/160
[i161]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/161
[i162]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/162
[i163]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/163
[i164]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/164
[i165]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/165
[i166]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/166
[i168]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/168
[i169]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/169
[i170]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/170
[i171]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/171
[i172]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/172
[i173]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/173
[i174]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/174
[i176]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/176
[i178]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/178
[i179]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/179
[i181]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/181
[i182]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/182
[i183]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/183
[i184]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/184
[i185]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/185
[i186]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/186
[i187]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/187
[i188]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/188
[i189]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/189
[i190]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/190
[i191]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/191
[i192]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/192
[i193]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/193
[i194]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/194
[i195]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/195
[i196]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/196
[i197]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/197
[i198]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/198
[i199]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/199
[i200]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/200
[i201]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/201
[i202]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/202
[i205]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/205
[i206]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/206
[i207]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/207
[i208]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/208
[i209]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/209
[i210]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/210
[i213]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/213
[i214]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/214
[i215]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/215
[i216]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/216
[i217]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/217
[i218]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/218
[i219]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/219
[i220]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/220
[i222]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/222
[i223]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/223
[i221]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/221
[i224]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/224
[i226]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/226
[i227]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/227
[i231]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/231
[i232]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/232
[i233]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/233
[i235]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/235
[i236]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/236
[i240]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/240
[i243]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/243
[i245]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/245
[i249]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/249
[i251]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/251
[i252]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/252
[i142]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/142
[i254]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/254
[i255]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/255
[i256]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/256
[i260]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/260
[i262]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/262
[i263]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/263
[i264]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/264
[i267]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/267
[i268]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/268
[i269]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/269
[i270]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/270
[i271]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/271
[i225]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/225

## Changelog
### 1.1.2 - use with FC 1.1.0
* Misc changes
	* [#224][i224]  Update main version number to 1.1.2; intended for developmental use towards 1.2.0
* Lua Rule File / Symbol Updates
	* [#226][i226] `LightSectored` with partially obscured sector will not portray arc with a dash
	* [#232][i232] Fix symbols with dots
	* [#233][i233] Support labeling contours deeper than 99m
	* [#227][i227] `DockArea` and `LockBasin` should always draw under RADAR
	* [#231][i231] `RadarStation` with `categoryOfRadarStation` = `2` is not showing communication channels
	* [#243][i243] Fix check for `majorLight` on `LightAllAround`
	* [#245][i245] `OBSTRN07.lua` should change line color based on `SafetyDepth`
	* [#240][i240] `SLCONS04.lua` incorrect evaluation of `condition` attribute
	* [#50][i50] `CATZOC` drawing priority should be `12`
 	* [#249][i249] Error when `valueOfLocalMagneticAnomaly` is unknown
  	* [#251][i251] Adjust `SAFCON90`
  	* [#252][i252] Adjust `SAFCON71` and `SAFCON91`
	* [#142][i142] Fix bug, reopened and added contains(7, categoryOfCargo)
	* [#213][i213] Within rule file, case inconsistency between reference and catalog entry for `SEAGRASS.svg`
	* [#254][i254] valueOfLocalMagneticAnomaly multiple value string fix
 	* [#255][i255] `LightSectored` portrayal results in `?`
  	* [#214][i214] `LocalMagneticAnomaly` change label color, label vg, and text offset.
  	* [#235][i235] Implement portrayal of `LandRegion` with curve geometry, `RescueStation` with surface geometry.
  	* [#260][i260] `CoastGuardStation` outputs duplicate drawing instructions
  	* [#256][i256] Ensure `inTheWater` is handled for all applicable feature types
  	* [#267][i267] Remove `NEWOBJ` symbols and linestyle
  	* [#269][i269] `DockArea` has incorrect priority and viewing group
  	* [#271][i271] `TOPMAR01.lua` renamed to `TOPMAR02.lua` because it implements the matching S-52 CSP
  	* [#236][i236] AnchorBerth categoryOfCargo = 7 (dangerous or hazardous cargo) new symbol ANCBDNG2 [PSWG #116]
  	* [#270][i270] VirtualAISAidToNavigation is using viewing group 21010 ---> changed to 27240
 	* [#268][i268] viewing group 28010 to add pilotage district [PSWG #147]
  	* [#262][i262] Precision of numeric values on dredged areas
  	* [#264][i264] Fix case of symbol file CSS references
  	* [#263][i263] Deal with incomplete `periodicDateRange`
	* [#225][i225] Update version number prior to release 1.1.2-DRAFT to 1.1.2

### 1.1.1 - use with FC 1.1.0
* [#216][i216] Use mariners viewing groups for alert highlights (`53010` - `53024`)
* [#182][i182] Ensure all unknown objects turn off with `Unknown` independent selection
* [#183][i183] Try to process codes which don't exist in the FC
* [#184][i184] Lost presentation of Anchorage Area
* [#185][i185] Incorrect reference to css file in DRFSTA02.SVG
* [#188][i188] `INFORM01` added to `LightSectored` with no `sectorInformation`
* [#189][i189] Some light descriptions are not visible
* [#190][i190] `LightSectored` with `sectorLineLength` portray as unknown objects
* [#192][i192] `UpdateInformation` is portrayed as unknown object
* [#194][i194] Features with undefined portrayal are not visible
* [#187][i187] Inconsistent types of variables during the drawing of Distance Mark
* [#191][i191] Issues with `Landmark` `categoryOfLandmark` = `22` (Triangulation Mark), `24` (Observation Wheel), and `25` (Torii)
* [#186][i186] Inconsistent colours of dash line and embedded symbol for `NAVARE52` linestyle (added EMAREGR2.svg)
* [#193][i193] Check for "noGeometry" in all No Geometry features, return null instruction
* [#196][i196] Viewing Groups 26010 and 26020 have identical names
* [#197][i197] Undefined parameter `TwoShades` for `ShallowContour` and `DeepContour`
* [#199][i199] Remove language independent text
* [#195][i195] Incorrect portrayal of Signal Station Traffic, removed 2021_SISTAT02_01.svg references 
* [#198][i198] Viewing Group 27220 missing for "Range System"
* [#200][i200] Viewing Group 27240 is not included in any Viewing Group Layer, added to 3
* [#202][i202] Symbol validation errors due to missing namespace prefix
* [#201][i201] Line style PILDSTR1.xml fails validation
* [#205][i205] Symbol validation errors due to incorrect namespace
* [#206][i206] `categoryOfAnchorage` has multiple values, use contains()
* [#207][i207] `INFORM01` symbol added to feature with no additional information
* [#193][i193] Check for "noGeometry" in all No Geometry features and moved to Viewing Group: 21060 Place-holder for geographic names  
* [#207][i207] `INFORM01` symbol added to feature with no additional information
* [#210][i210] `Crane` type surface has 0.64 lineweight for boundary opposed to 0.32 in S-52
* [#213][i213] Case inconsistency between filename and catalog entry for `SEAGRASS.svg`
* [#209][i209] Conveyor.lua has duplicate conditions, removed duplicates
* [#217][i217] Remove `DISMAR03.svg` and `DISMAR04.svg`
* [#218][i218] Removal of alerts from `RestrictedAreaRegulatory` is not yet approved
* [#219][i219] Remove national language text from the alert catalog
* [#220][i220] Set `SafetyContour` alert priority in route planning mode to `Alarm`
* [#222][i222] Many symbols missing namespace prefix on `Description` element and metadata attributes
* [#223][i223] Symbols with invalid `creationDate` attribute
* [#221][i221] Removed SISTAT02.svg from PC, no rules reference it
* [#215][i215] Update version number prior to release 1.1.1b to 1.1.1

### 1.1.0 - use with FC 1.1.0
*	Misc changes
*	[#153][i153] Update PortrayalCreateContextParameter contextParameterType to allow "Double" and "String" and to ignore case
*	[#154][i154] Enhance debugging
*	[#155][i155] Update context parameters
*	[#159][i159] Remove processing instruction
*	[#160][i160] Update version number
*	[#138][i138] Modified metadata for Incorrect drawing of some Area patterns [PSWG #92] #138
*	[#163][i163] Update FC to 1.1.0
*	[#179][i179] Update PC display modes to match registered values
*	Lua Rule File / Symbol Updates
	*	[#143][i143] New Symbology for Pilot Boarding Place surface [PSWG#106] 
	*	[#137][i137] Pilotage District Symbology [PSWG #105]
	*	[#133][i133] Update DGPS reference station symbol to DRFSTA02 [PSWG #111] #133
	*	[#139][i139] Update EMLOWACnn.svg symbols (reduce line thickness)
	*	[#140][i140] Update Deep water route line styles (eliminate leading space)
	*	[#10][i10] Change sector extension from 3mm to 5mm
	*	[#162][i162] BuoyNewDangerMarking -> BuoyEmergencyWreckMarking
	*	[#164][i164] DredgedArea TextInstruction display priority 24 -> 3
	*	[#131][i131] Enable the symbolisation of Reeds - [PSWG #109] 
	*	[#165][i165] Crane: throw error on curve geometry
	*	[#166][i166] FoulGround: throw error on curve geometry
	*	[#168][i168] Active submarine volcano must have point geometry
	*	[#169][i169] Restricted anchorage must have point geometry
	*	[#170][i170] flareAngle renamed to flareBearing
	*	[#171][i171] sectorLineLength units changed from meters to nautical miles
	*	[#141][i141] Amend incorrect S-52 color for symbol SOUNDSC2 -> SOUNDSC3 [PSWG #118], #141
	*	[#141][i141] Corrected prior fix: incorrect S-52 color for symbol SOUNDSC2 -> SOUNDSC3 [PSWG #118], #141
	*	[#172][i172] Implement SeparationZoneOrLine
	*	[#97][i97] Completed: Physical AIS Aid to Navigation [PSWG #70], VG = 27240 (as per S-98)
	*	[#173][i173] Dock Area and Lock Basin - Define Display parameters [PSWG #121]
	*	[#145][i145] "No Geometry" features work-around for PC #145 thru PC #152, [PSWG #80 thru #87]
	*	[#145][i145] Removed debug for "No Geometry" features work-around for PC #145 thru PC #152, [PSWG #80 thru #87]
	*	[#176][i176] Runway feature of type Point [attribute categoryOfRunway=1 (Aeroplane Runway)] - Map to AIRARE02
	*	[#142][i142] Symbol Berth features with categoryOfCargo = 7 [PSWG #112]
	*	[#134][i134] Update portrayal of Heliports / Helipads
	*	[#119][i119] Independent mariner selections
	*	[#73][i73]  Value of Local Magnetic Anomaly #73 [PSWG #102] 
	*	[#161][i161] Sloping Ground & Slope Topline #108, [PSWG #108]
	*	[#178][i178] QoBD should evaluate depth range
	*	[#16][i16] symbols: viewBox mismatch
	*	[#24][i24] use new symbol for conspicuous flagstaff (FLGSTF02)
	*	[#61][i61] update GetFeatureName per https://github.com/S-101-Portrayal-subWG/Working-Documents/issues/104#issuecomment-1469246446
	*	[#174][i174] INFORM01 symbol should be displayed when feature itself contains information
	*	[#181][i181] WRECKS05.lua raises an error in some conditions
	*	[#61][i61] Removed NationalLanguage context parameter pending resolution of https://github.com/iho-ohi/S-101-Documentation-and-FC/issues/60 and https://github.com/S-101-Portrayal-subWG/Working-Documents/issues/104

### 1.0.2 - use with FC 1.0.2
*	Change version numbering scheme to match FC and DCEG
*	[#67][i67] Update for S-100 v5.0 schemas
*	[#68][i68] Add portrayal context parameter validation rules
*	[#84][i84] Fix symbolBox for FOULGD02.svg
*	Lua Rule File Updates
	*	[#27][i27] Feature CoastguardStation -> CoastGuardStation
	*	[#28][i28] Attribute visuallyConspicuous -> visualProminence
	*	[#29][i29] Attribute categoryOfRecommendedTrack -> basedOnFixedMarks
	*	[#33][i33] Default symbology for areas missing outline
	*	[#34][i34] Token LITGN incorrect name/description
	*	[#36][i36] Current Non Gravitational (Removed Curve and Surface rule parts)
	*	[#34][i37] Deep Water Route
	*	[#39][i39] Foul Ground point, replaced FOULGND1 with FOULGD02
	*	[#40][i40] Discoloured Water point, replaced testPCB with DSCWTR01 for points only
	*	[#41][i41] Buoy New Danger Marking rule added 
	*	[#44][i44], [#70][i70] changes to default symbology
	*	[#46][i46] New symbol for CEVNI system of marks, 'DIRBOY02'
	*	[#48][i48] Fix display category for UnderwaterAwashRock
	*	[#49][i49] Wrecks with missing attribute values should be assigned to 'Base' display category
	*	[#50][i50] Quality of Bathymetric Data, use S-52 symbology based on CATZOC value
	*	[#51][i51] Implement Virtual AIS Aid to Navigation
	*	[#52][i52] Call Activated [Signal Generation], FogSignal.lua and LightFlareAndDescription.lua
	*	[#53][i53] Coral Sanctuary [Category of Restricted Area] added to rule RESARE04.lua
	*	[#54][i54] _categoryOfPipelinePipe_ 7 (bubble curtain) added to rule PipelineSubmarineOnLand.lua
	*	[#55][i55] Disengagement Area added according to issue note
	*	[#56][i56] Dredged Area display dredged date, in brackets, after depthRangeMinimumValue
	*	[#57][i57] UnderwaterAwashRock (UWTROC) missing NavHazard alert
	*	[#59][i59] _categoryOfCable_ 7 (ferry) added to rule CableSubmarine.lua
	*	[#60][i60] LightAllAround now uses _majorLight_ to determine when to draw halo
	*	[#62][i62] Use _flareAngle_ attribute in LightFlareAndDescription.lua
	*	[#63][i63] 'Fla' text added to point and surface for OffshorePlatform.lua with Flare Stack
	*	[#64][i64] categoryOfFerry 5 (High Speed Ferry) added to rule FerryRoute.lua
	*	[#65][i65] DistanceMark / measured distance value
	*	[#69][i69] VirtualAISAidToNavigation should generate NavHazard alert
	*	[#70][i70] Handle date dependency/nautical information for default symbology
	*	[#72][i72] Fix display category for Obstructions
	*	[#73][i73] Value of Local Magnetic Anomaly as maximum value text
	*	[#76][i76] Sloping Ground, Removed categoryOfSlopingGround= 5 & 7 from list of valid attribute values
	*	[#78][i78] Implement categoryOfShorelineConstruction == 22 (Quay)
	*	[#41][i41], [#77][i77]  Changed symbol to BOYNDM01, removed old rule from PC.xml
	*	[#79][i79], [#9][i9]  Allocate portrayal parameters to SY(CHDATD01)
	*	[#82][i82] Multiplicity of categoryOfRadioStation changed
	*	[#86][i86] LocalOffset unintentionally applied
	*	[#89][i89] Associate INFORM, text, etc. with override viewing group returned from UDWHAZ05
	*	[#90][i90] Display of quality symbol returned from QUAPNT02 should toggle with features base viewing group
	*	[#91][i91] LITDSN02.lua "status" labels not present
	*	[#92][i92] _communicationChannel_ attribute moved from feature to information type
	*	[#95][i95] RestrictedAreaRegulatory call to RestrictedAreaNavigational fails	
	*	[#96][i96] LightSectored directional light with unknown orientation calls Default.lua	
	*	[#100][i100] Type of _sectorExtension_ changed from integer to boolean
	*	[#46][i46] Updated guidance implemented based on PSWG #64 decisions, remove LC(MARSYS51) etc
	*	[#47][i47] Remove symbolisation from ALL NavigationalSystemOfMarks Surface boundaries, PSWG #42
	*	[#30][i30] Marine Pollution Regulations Area as S-52 ADMARE features,  PSWG #74
	*	[#109][i109] Collision Regulations Limit symbol added but needs viewing group etc. PSWG #41
	*	[#104][i104] Added Torii [Category of Landmark = 25], also see PSWG #60
	*	[#101][i101] Added Seagrass new symbology, also see PSWG #47
	*	[#56][i56] Additional guidance on dredged date see Aug 3, 2022 comments
	*	[#76][i76] Sloping Ground, revert back to portrayal to match S-52 look-up tables, PSWG #35
	*	[#30][i30] Marine Pollution Regulations Area added to Viewing Group Layer 18 (Miscellaneous),  PSWG #74
	*	[#109][i109] Updated Collision Regulations Limit viewing group etc. PSWG #41
	*	[#117][i117] Vessel Traffic Service Area new symbology.  PSWG #50
	*	[#103][i103] Active Submarine Volcano [Category of Obstruction] new point symbol ver 3.  PSWG #71
	*	[#107][i107] New symbol: Observation Wheel [Category of Landmark],  FERWHL03 and FERWHL04.  PSWG #62
	*	[#105][i105] Restricted Area Regulatory break-out and new viewing group 26020.  PSWG #31
	*	[#103][i103] Active Submarine Volcano [Category of Obstruction] new point symbol ver 4.  PSWG #71
	*	[#113][i113] Moiré Effect [Directional Character] new symbol.  PSWG #52
	*	[#122][i122] Coast Guard Station {Surface}, central symbol
	*	[#121][i121] Reported Anchorage [Category of Anchorage] = 15, new symbol. PSWG #72.
	*	[#114][i114] Tank Farm, Category of Offshore Production Area, new symbol. PSWG #54.
	*	[#122][i122] Coast Guard Station, fixed drawing priority 7 ---> 21
	*	[#108][i108] Triangulation Mark [Category of Landmark], New rule and symbol. PSWG #66.
	*	[#111][i111] Signal Station Traffic, New rule and symbol. PSWG #48.
	*	[#112][i112] Signal Station Warning, New rule and symbol. Removed symbol SISTA02 from PC. PSWG #49.
	*	[#114][i114] Tank Farm, Category of Offshore Production Area, change symbol name only. PSWG #54.
	*	[#94][i94] Implement portrayal rule for Pilotage District with new symbology.  PSWG #57.
	*	[#114][i114] Remaining "farm" symbols updated with new rule logic. PC #114, PSWG #63, #55, #67, #67, #54
	*	[#112][i112] Rename 2021_SISTAT03.svg to SISTAT03.svg. PC #112, PSWG #49
	*	[#112][i112] Wrong symbol used in SignalStationWarning.lua corrected from SISTAT03 to SISTAW03. PC #112, PSWG #49
	*	[#98][i98] Support Pile curve and surface geometries
	*	[#125][i125] All symbols should default to "daySVGStyle.css"
	*	[#110][i110] Implement portrayal of InformationArea, replacing use of "testPCB"
	*	[#111][i111] Symbol decision and name change 2022_SISTAT03.svg to SISTAT03.svg, PSWG #48.
	*	[#40][i40] Discoloured Water updated rule based on decision on SEPT 1, 2022. PSWG #61.
	*	[#47][i47] Remove symbolisation from ALL NavigationalSystemOfMarks Surfaces, (NULL instruction for Pick Report only), PSWG #42
	*	[#46][i46] Rule clean-up based on attributes 'marksNavigationalSystemOf' and 'orientationValue', PSWG #64 and PC #46
	*	[#39][i39] Foul Ground new symbols and rule updates, PSWG #65, PC #39
	*	[#124][i124] New symbol and rule update for Anchorage Area with small craft moorings, PSWG #28, PC #124
	*	[#106][i106] Crane rule updates, PSWG #75, PC #106
	*	[#126][i126] DiscolouredWater missing central symbols, PSWG #61, PC #126
	*	[#20][i20] Sector lights draw leg lines to sector line length when full sectors is off
	*	[#23][i23] Change to portrayal of mangroves, PSWG #34, PC #23
	*	[#80][i80] Implement date dependent support for QoBD
	*	[#126][i126] DiscolouredWater updated with zero offset central symbol, PSWG #61, PC #126

### Version numbers below correspond to 1.0.0 in the current version numbering scheme

### 1.1.5 - use with FC 1.0.0 of 2019-04-09
*	[#14][i14] Use correct drawing priority for LightAllAround features
*	[#18][i18] Fix name for viewing groups 32030 and 32050
*	[#25][i25] Alerts generated by restricted areas have incorrect highlight viewing group
*	[#26][i26] Fix S-64 hazards sometimes have incorrect viewing group

### 1.1.4 - use with FC 1.0.0 of 2019-04-09
*	Removed mariners viewing groups and viewing group layers
*	Correctly handle missing attribute values for attributes with an upper multiplicity of one
*	Draw Foul Ground point symbols under RADAR when Radar Overlay context parameter is false
*	Rework TextInstruction commands by removing viewing group and drawing priority parameters
*	Use same symbolization for RestrictedAreaRegulatory as for RestrictedAreaNavigational
*	[#4][i4] Don't treat prominent features as visually conspicuous
*	[#6][i6] Assign the viewing group for wrecks based on results of UDWHAZ05
*	Use multiple viewing groups to implement symbol / text dependencies, see [Change Proposal Form](https://github.com/IHO-S100WG/TSM8/blob/master/6.X-1%20Multiple%20viewing%20groups%20per%20drawing%20instruction/Allow%20multiple%20viewing%20groups%20per%20drawing%20instruction.pdf)
*	[#7][i7] Don't show VALSOU on curve obstruction hazard symbol
*	Display feature name for Bridge features in viewing group 26 instead of 21
*	[#5][i5] Update context parameter defaults per IEC 61174 ed4 Table 3
	* Full light lines: off
	* Shallow water dangers: on
	* Plain/symbolized boundaries: plain
	* Radar overlay: off

### 1.1.3 - use with FC 1.0.0 of 2019-04-09
*	Draw 360 degree arc around LightAllAround when appropriate
*	Assign shallow water pattern to proper viewing group
*	Handle blue and yellow lights properly
*	Viewing group layers implementing S-52 text group layers are no longer included in a display mode
*	Portray FoulGround feature in accordance with S-52 rules for OBSTRN where CATOBS = 7
*	Fixed handling of restricted areas with no listed restrictions
*	Reset rotation after drawing rotated symbol

### 1.1.2 - use with FC 1.0.0 of 2019-04-09
*	Remove catalog entry for deleted file svgStyle.css
